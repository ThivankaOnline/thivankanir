

<div align="center">
  <img src="https://telegra.ph/file/35883180004518cb15fe9.jpg" width="300" height="300">
	<div align="center">


  <h1>🇱🇰 𝗗𝗥𝗔𝗚𝗢𝗡 𝗫  𝗪𝗛𝗔𝗧𝗦𝗔𝗣𝗣 𝗕𝗢𝗧 🕊 </h1> 
</div>
<p align="center">
    World best Sinhala/English WhatsApp Button Bot Developer Janith Sadanuwan Enjoy Our Bot
    <br>
        <a href="https://chat.whatsapp.com/LhWT3s3koJx6kkUROPtUeD">Whatsapp Group</a> |
        <a href="https://www.youtube.com/c/Janithsadanuwan">Youtube Channel</a>
    <br>
</p>
	
### QR CODE
[![Run on Repl.it](https://repl.it/badge/github/quiec/whatsasena)](https://replit.com/@Janithsadanuwan/petlhi-Qr?v=1)

### Deploy Page
[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/Janithsadanuwan/Dragonx-Whatsapp-Bot)
</div>

---- 

<p align="center">

  <a href="https://github.com/Janithsadanuwan/Dragonx-Whatsapp-Bot">
    <img src="https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https%3A%2F%2Fgithub.com%2FAchiyaCT%2FALPHA-V4&count_bg=%2379C83D&title_bg=%23555555&icon=gitpod.svg&icon_color=%23E7E7E7&title=Views&edge_flat=false" alt="Views"/></a>
  
  </a>
  <a href="https://github.com/Janithsadanuwan/Dragonx-Whatsapp-Bot">
    <img src="https://img.shields.io/github/forks/Janithsadanuwan/Dragonx-Whatsapp-Bot?label=Fork&style=social">
    
  </a>
  <a href="https://github.com/Janithsadanuwan/Dragonx-Whatsapp-Bot/stargazers">
    <img src="https://img.shields.io/github/stars/Janithsadanuwan/Dragonx-Whatsapp-Bot?style=social">
  </a>
</p>

<p align="center">
  <a href="https://github.com/Janithsadanuwan/Dragonx-Whatsapp-Bot">
    <img src="https://img.shields.io/github/repo-size/Janithsadanuwan/Dragonx-Whatsapp-Bot?color=purple&label=Repo%20Size&style=plastic">

  </a>
  <a href="https://github.com/Janithsadanuwan/Dragonx-Whatsapp-Bot">
    <img src="https://img.shields.io/github/license/Janithsadanuwan/Dragonx-Whatsapp-Bot?color=purple&label=License&style=plastic">

  </a>
  <a href="https://github.com/Janithsadanuwan/Dragonx-Whatsapp-Bot">
    <img src="https://img.shields.io/github/languages/top/Janithsadanuwan/Dragonx-Whatsapp-Bot?color=purple&label=Javascript&style=plastic">

  </a>
  <a href="https://github.com/Janithsadanuwan/Dragonx-Whatsapp-Bot">
    <img src="https://img.shields.io/static/v1?label=Author&message=Janith%20Sadanuwan&color=purple&style=plastic">

  </a>
</p>
## License
මෙම ව්‍යාපෘතිය `GNU General Public License v3.0` බලපත්රයෙන් ආරක්ෂා කර ඇත.
ප්‍රකාශන හිමිකම් පණිවිඩ සංස්කරණය නොකරන්න!

### Disclaimer
`WhatsApp` name, එහි වෙනස්කම් සහ ලාංඡනය ෆේස්බුක් හි ලියාපදිංචි වෙළඳ ලකුණු වේ. ලියාපදිංචි වෙළඳ ලකුණ සමඟ අපට කිසිදු සම්බන්ධයක් නැත.
<div align="center">  
	

	
	
	
	
	
	
